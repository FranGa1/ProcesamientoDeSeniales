[n, x] = senial(26287);

y1 = sistema1(x);
plotCompletoSVID(n,y1, 'Sistema 1', 'n', 'y1[n]')

y2 = sistema2(x);
plotCompletoSVID(n,y2, 'Sistema 2', 'n', 'y2[n]')

y3 = sistema3(x);
plotCompletoSVID(n,y3, 'Sistema 3', 'n', 'y3[n]')

y4 = sistema4(x);
plotCompletoSVID(n,y4, 'Sistema 4', 'n', 'y4[n]')
