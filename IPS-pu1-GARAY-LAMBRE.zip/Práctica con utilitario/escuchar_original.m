[x, fs] = audioread('./AnSyS2022_PU1_m/audio.wav');
sound(x, fs)