addpath('./AnSyS2022_PU1_m');

[n, h] = hcanald(26287);

plotCompletoSVID(n, h, 'Respuesta Impulsional', 'n', 'h[n]');